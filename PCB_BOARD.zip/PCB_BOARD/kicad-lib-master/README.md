# CVRA KiCAD footprint libraries

This repository contains a set of footprint we use at the [CVRA](http://cvra.ch) for various projects.

It is provided under a [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) license.
